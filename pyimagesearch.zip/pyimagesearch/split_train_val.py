import os
import shutil
from sklearn.model_selection import train_test_split

class Split_train_val:
    @staticmethod
    def test_train_split(dataset,testSize):
        print(dataset)
        dataset='./'+dataset
        print(dataset)
        if not os.path.exists('training_data'):
            os.makedirs("./training_data")
        if not os.path.exists('testing_data'):
            os.makedirs("./testing_data")
        for root, dirs, files in os.walk(dataset, topdown=False):
            if root == dataset:
                for name in dirs:
                    #print(dirs)
                    #print(root)
                    X =y = os.listdir(root+"/"+name)
                    if not os.path.exists("./training_data/"+name):
                        os.makedirs("./training_data/"+name)
                    if not os.path.exists("./testing_data/"+name):
                        os.makedirs("./testing_data/"+name)
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=testSize, random_state=0)
                    for x in X_train:
                        source = root+'/'+name+'/'+x
                        print(source)
                        target = './training_data/'+name
                        print(target)
                        shutil.copy(source, target)
                        #print(root+"/"+name+"/"+x,"./training_data/"+name+"/"+x)
                        #os.rename(root+"/"+name+"/"+x,  "./training_data/"+name+"/"+x)
                    for x in X_test:
                        source = root+'/'+name+'/'+x
                        print(source)
                        target = './testing_data/'+name
                        print(target)
                        shutil.copy(source, target)
                        #print(root+"/"+name+"/"+x,"./testing_data/"+name+"/"+x)
                        #os.rename(root+"/"+name+"/"+x, "./testing_data/"+name+"/"+x)
    

